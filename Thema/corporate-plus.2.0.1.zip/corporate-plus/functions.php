<?php
/**
 * Corporate Plus functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Acme Themes
 * @subpackage Corporate Plus
 */

/**
 * Require init.
 */
require_once trailingslashit( get_template_directory() ).'acmethemes/init.php';