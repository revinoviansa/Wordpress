
 ### v0.6 - 2018-05-31 
 **Changes:** 
 * Added Telegram icon support in Social Icons section
 * Added GDPR Comment checkbox style
 * Added WD Insagram feed plugin Compatibility
 * Updated fontawesome to 4.7
 * Fixed Single Post page's Microformat issue
 * Fixed Customizer Layout
 
 
